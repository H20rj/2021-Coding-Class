using System;

class Program {
    static void Main(string[] args) 
      
    {
      //This is generating a random number
      Random r = new Random(); 
      int winNum = r.Next(0,100);
      Console.WriteLine(winNum);
      
      
      if (winNum == 48)
        {
        Console.WriteLine("How are you that lucky");
        }
      else
        {
        Console.WriteLine("Unlucky");
        }

    }   
}